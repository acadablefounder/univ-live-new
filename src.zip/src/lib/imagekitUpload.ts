// src/lib/imagekitUpload.ts
export async function uploadToImageKit(file: Blob, fileName: string, folder = "/question-bank") {
  const publicKey = import.meta.env.VITE_IMAGEKIT_PUBLIC_KEY as string;

  if (!publicKey) throw new Error("Missing VITE_IMAGEKIT_PUBLIC_KEY");

  // 1) get signature from backend
  const authRes = await fetch("/api/imagekit-auth");
  if (!authRes.ok) throw new Error("Failed to get ImageKit auth");
  const auth = await authRes.json(); // { token, expire, signature }

  // 2) upload to ImageKit
  const form = new FormData();
  form.append("file", file);
  form.append("fileName", fileName);
  form.append("publicKey", publicKey);
  form.append("signature", auth.signature);
  form.append("expire", String(auth.expire));
  form.append("token", auth.token);
  form.append("folder", folder);
  form.append("useUniqueFileName", "true");

  const uploadRes = await fetch("https://upload.imagekit.io/api/v1/files/upload", {
    method: "POST",
    body: form,
  });

  if (!uploadRes.ok) {
    const txt = await uploadRes.text().catch(() => "");
    throw new Error(`ImageKit upload failed: ${uploadRes.status} ${txt}`);
  }

  const json = await uploadRes.json();

  return {
    url: json.url as string,
    fileId: json.fileId as string,
    name: json.name as string,
  };
}

